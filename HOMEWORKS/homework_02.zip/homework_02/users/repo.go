package users

type RepoInfo struct{
	Name string `json:"name"`
	Forks int `json:"forks_count"`
}
